export class Customer 
{
    custid:number|undefined;
    custname:string|undefined;
    custcity:string|undefined;

}
