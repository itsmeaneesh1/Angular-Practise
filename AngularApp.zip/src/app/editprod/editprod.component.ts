import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editprod',
  templateUrl: './editprod.component.html',
  styleUrls: ['./editprod.component.css']
})
export class EditprodComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
