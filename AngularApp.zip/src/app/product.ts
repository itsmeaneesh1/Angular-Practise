export class Product 
{
    prodid:string|undefined;
    prodname:string|undefined;
    price:number|undefined;
    category:string|undefined;
}
